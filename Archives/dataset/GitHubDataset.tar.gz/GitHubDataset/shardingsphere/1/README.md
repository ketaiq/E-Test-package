Fixed at commit cf1719b

Failure type: new input of string.

`InsertClauseShardingConditionEngineTest.java` contains all existing test cases.
`InsertClauseShardingConditionEngine.java` contains the buggy implementation of `appendMissingShardingConditions`.
`NewTestCase.txt` contains new test case that can reproduce the failure with the buggy implementation.

`git checkout cf1719b~1` to get the complete the buggy implementation.