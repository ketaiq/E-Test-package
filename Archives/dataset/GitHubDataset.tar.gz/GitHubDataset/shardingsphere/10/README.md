Fixed at commit b8f4d8d

Failure type: new input of object.

`OrderByContextEngineTest.java` contains all existing test cases.
`OrderByContextEngine.java` contains the buggy implementation of `public OrderByContext createOrderBy`.
`NewTestCase.txt` contains new test case that can reproduce the failure with the buggy implementation.

`git checkout b8f4d8d~1` to get the complete the buggy implementation.