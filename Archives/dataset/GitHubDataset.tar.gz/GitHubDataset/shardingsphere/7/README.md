Fixed at commit 83942fd

Failure type: new input of object.

`MySQLPacketCodecEngineTest.java` contains all existing test cases.
`MySQLPacketCodecEngine.java` contains the buggy implementation of `isValidHeader()`.
`NewTestCase.txt` contains new test case that can reproduce the failure with the buggy implementation.

`git checkout 83942fd~1` to get the complete the buggy implementation.