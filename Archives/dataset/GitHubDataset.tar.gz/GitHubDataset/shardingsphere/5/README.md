Fixed at commit a5b7aff

Failure type: new input of object.

`OnDuplicateUpdateContextTest.java` contains all existing test cases.
`OnDuplicateUpdateContext.java` contains the buggy implementation of `calculateParameterCount`.
`NewTestCase.txt` contains new test case that can reproduce the failure with the buggy implementation.

`git checkout a5b7aff~1` to get the complete the buggy implementation.