Fixed at commit 8efaa9f

Failure type: new input of string.

`SensitiveDataConverterTest.java` contains all existing test cases.
`DataSourceConstants.java` contains the buggy implementation of `DATASOURCE_PASSWORD_REGEX`.
`NewTestCase.txt` contains new test cases that can reproduce the failure with the buggy implementation.

`git checkout 8efaa9f~1` to get the complete the buggy implementation.