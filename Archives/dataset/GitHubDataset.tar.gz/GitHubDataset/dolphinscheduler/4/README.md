Fixed at commit b3af374

Failure type: new input of string under different environments.

No existing test cases before.
`ProcessUtils.java` contains the buggy implementation of `getPidsStr`.
`NewTestCase.txt` contains new test cases that can reproduce the failure with the buggy implementation.

`git checkout b3af374~1` to get the complete the buggy implementation.