Fixed at commit 635d9db

Failure type: new input of string.

`ProxyBackendHandlerFactoryTest.java` contains all existing test cases.
`ProxyBackendHandlerFactory.java` contains the buggy implementation of `public static ProxyBackendHandler newInstance`.
`NewTestCase.txt` contains new test case that can reproduce the failure with the buggy implementation.

`git checkout 635d9db~1` to get the complete the buggy implementation.