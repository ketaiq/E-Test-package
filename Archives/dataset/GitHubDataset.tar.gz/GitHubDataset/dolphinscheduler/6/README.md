# apache/dolphinscheduler issue 14040

ref: https://github.com/apache/dolphinscheduler/pull/14040

## Description

Exception when using host in ipv6 format. For example，2001:1:0:4F3A::206:AE14 is valid IPV6, but !IPV4_PATTERN.matcher("2001:1:0:4F3A::206:AE14").matches() return true.

`checkHost` in `AbstractDataSourceProcessor.java` is the buggy implementation.
`AbstractDataSourceProcessorTest.java` contains all existing test cases.

New input: "2001:1:0:4F3A::206:AE14"


