Fixed at commit 68c1008

Failure type: new input of string.

`TableRuleTest.java` contains all existing test cases.
`TableRule.java` contains the buggy implementation of `DATA_NODE_SUFFIX_PATTERN`.
`NewTestCase.txt` contains new test case that can reproduce the failure with the buggy implementation.

`git checkout 68c1008~1` to get the complete the buggy implementation.