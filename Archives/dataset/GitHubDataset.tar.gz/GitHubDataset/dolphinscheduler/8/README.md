# apache/dolphinscheduler issue 13378

ref: https://github.com/apache/dolphinscheduler/pull/13378

## Description

parsing error while parsing hive load sql with quotes

`AbstractTask.java` includes the buggy `public String rgex`, which is extended by SqlTask.

`NewTestCase.java` includes all tests to reproduce the bug.