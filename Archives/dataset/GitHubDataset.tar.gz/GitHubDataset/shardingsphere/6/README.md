Fixed at commit 86196a9

Failure type: new input of object.

`ExpressionBuilderTest.java` contains all existing test cases.
`ExpressionBuilder.java` contains the buggy implementation of `extractAndPredicates()`.
`NewTestCase.txt` contains new test case that can reproduce the failure with the buggy implementation.

`git checkout 86196a9~1` to get the complete the buggy implementation.