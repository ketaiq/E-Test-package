## Description

OSUtils.cpuUsage() function will produce NumberFormatException if cpuUsage() function returns 0.0 / 0.0 = NaN.

Fixed at commit 0e7403e

Failure type: new input of string under different environments.

`OSUtilsTest.java` contains existing test cases before.
`OSUtils.java` contains the buggy implementation of `cpuUsage`.
`NewTestCase.txt` contains new test cases that can reproduce the failure with the buggy implementation.

`git checkout 0e7403e~1` to get the complete the buggy implementation.