Fixed at commit 926d7de

Failure type: new input of object.

`ConditionValueBetweenOperatorGeneratorTest.java` contains all existing test cases.
`ConditionValueBetweenOperatorGenerator.java` contains the buggy implementation of `public Optional<RouteValue> generate`.
`NewTestCase.txt` contains new test case that can reproduce the failure with the buggy implementation.

`git checkout 926d7de~1` to get the complete the buggy implementation.