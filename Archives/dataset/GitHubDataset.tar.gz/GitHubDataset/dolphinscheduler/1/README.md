Fixed at commit 5e3dc7b

Failure type: new input of object.

`UsersServiceTest.java` contains all existing test cases.
`UsersServiceImpl.java` contains the buggy implementation of `grantProjectWithReadPerm`, `grantProject`, `grantUDFFunction`.
`NewTestCase.txt` contains new test cases that can reproduce the failure with the buggy implementation.

`git checkout 5e3dc7b~1` to get the complete the buggy implementation.