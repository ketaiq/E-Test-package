Fixed at commit 198fed5

Failure type: new input of object.

There are no existing test cases.
`JdbcUtil.java` contains the buggy implementation of `public static String getSchema`.
`NewTestCase.txt` contains new test case that can reproduce the failure with the buggy implementation.

`git checkout 198fed5~1` to get the complete the buggy implementation.