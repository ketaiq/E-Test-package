# apache/dolphinscheduler issue 10284

ref: https://github.com/apache/dolphinscheduler/pull/10284

## Description

when the default time zone of the TimeZone class is set in other places through TimeZone.setDefault, the initialization of JSONUtils is carried out. At this time, JSONUtils final and static descriptors are modified parts The default time zone information in TimeZone will be loaded, and setting the TimeZone time zone via TimeZone.setDefault(TimeZone.getTimeZone("Asia/Shanghai")) in the future will not have any effect on JSONUtils.

`dateToString` and `stringToDate` in `NewTestCase.txt` can reproduce the bug.
`JSONUtils.java` contains the buggy implementation without setting time zone.

Fix commit: 062146e