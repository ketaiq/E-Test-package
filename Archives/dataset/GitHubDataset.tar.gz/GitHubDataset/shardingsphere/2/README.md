Fixed at commit 281aa7d

Failure type: new input of string.

`JDBCMemoryQueryResultTest.java` contains all existing test cases.
`AbstractMemoryQueryResult.java` contains the buggy implementation of `getValue`, `getCalendarValue`, `getInputStream`.
`NewTestCase.txt` contains new test case that can reproduce the failure with the buggy implementation.

`git checkout 281aa7d~1` to get the complete the buggy implementation.